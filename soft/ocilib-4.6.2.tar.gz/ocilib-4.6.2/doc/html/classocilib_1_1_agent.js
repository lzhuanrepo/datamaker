var classocilib_1_1_agent =
[
    [ "Agent", "classocilib_1_1_agent.html#affb689fd24c780f9e25d713c042ddf45", null ],
    [ "GetName", "classocilib_1_1_agent.html#aea0ae8413708604fd1bb4629c1d9c35d", null ],
    [ "SetName", "classocilib_1_1_agent.html#a8cf39298ceae611b2499244e97c23baa", null ],
    [ "GetAddress", "classocilib_1_1_agent.html#aa8953ebb12a1393201c34cfa41cd4c1e", null ],
    [ "SetAddress", "classocilib_1_1_agent.html#a44b3a42c020de9077c1ddeab63d0f5fd", null ]
];