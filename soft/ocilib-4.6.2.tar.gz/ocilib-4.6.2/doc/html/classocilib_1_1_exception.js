var classocilib_1_1_exception =
[
    [ "ExceptionType", "classocilib_1_1_exception.html#af54734ce66b6867010be73466c8f822c", null ],
    [ "ExceptionTypeValues", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8c", [
      [ "OracleError", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8ca333285a9580d1637d8398204c282cbcc", null ],
      [ "OcilibError", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8ca7aa90bd6ce524a4a84ceb8a1e2dc9832", null ],
      [ "OracleWarning", "classocilib_1_1_exception.html#a1c4917298b7dee8f7b0bcd5279bffb8caaab61cccf5ae513931572515748156ad", null ]
    ] ],
    [ "~Exception", "classocilib_1_1_exception.html#a5a9f6c690534edd884eac929b15e69e8", null ],
    [ "GetMessage", "classocilib_1_1_exception.html#a23ee359af658d3a068a0f5256ca16b55", null ],
    [ "GetType", "classocilib_1_1_exception.html#a96a5dcf8511d0d8fa30e9d98dab66f5a", null ],
    [ "GetOracleErrorCode", "classocilib_1_1_exception.html#a6cdb247ecc20e7e0f8815797669b8e97", null ],
    [ "GetInternalErrorCode", "classocilib_1_1_exception.html#aa32d9d5eb10b364d276ce2ba6a74a921", null ],
    [ "GetStatement", "classocilib_1_1_exception.html#ad0feb150c8d52f3f5fd646e3e9c5435d", null ],
    [ "GetConnection", "classocilib_1_1_exception.html#aa27e74a7461709afabac83d71628a2d1", null ],
    [ "GetRow", "classocilib_1_1_exception.html#a8c06341ba16889cf92da380789fd8cd2", null ],
    [ "what", "classocilib_1_1_exception.html#a6ace067c331ec12cdb7ef3b810e74068", null ],
    [ "Check", "classocilib_1_1_exception.html#ad3fde29600e69dd993abf5d317fc325c", null ]
];