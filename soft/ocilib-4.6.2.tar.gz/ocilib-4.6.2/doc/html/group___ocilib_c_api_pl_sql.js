var group___ocilib_c_api_pl_sql =
[
    [ "OCI_ServerEnableOutput", "group___ocilib_c_api_pl_sql.html#gaeff8f38ba15b9e757cec70d91e4ffe13", null ],
    [ "OCI_ServerDisableOutput", "group___ocilib_c_api_pl_sql.html#ga0d3321a0abff0722baf6b2b7233f4cb5", null ],
    [ "OCI_ServerGetOutput", "group___ocilib_c_api_pl_sql.html#gaac2621ca13cc7a4e862ae8d93493f684", null ]
];