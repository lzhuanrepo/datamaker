var classocilib_1_1_event =
[
    [ "EventType", "classocilib_1_1_event.html#ab1ad2443de7d59c7fcd11912ce7b204c", null ],
    [ "ObjectEvent", "classocilib_1_1_event.html#a4271828f7e60552f635b0154a2c25554", null ],
    [ "EventTypeValues", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383e", [
      [ "DatabaseStart", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383ea830b8a12508b6691d83a62689e07d643", null ],
      [ "DatabaseShutdown", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383eacef7d0bc6849aed59c435d39bb753665", null ],
      [ "DatabaseShutdownAny", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383ea0413ea4c9e3fe486ddda39189a8c6766", null ],
      [ "DatabaseDrop", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383eaae6d29812ffeffa0db1ae1f26fd03010", null ],
      [ "Unregister", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383ead90ec9724417d56869f76366a04bdcae", null ],
      [ "ObjectChanged", "classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383ead2402566e03ab9dd521f1d03c0a6bc13", null ]
    ] ],
    [ "ObjectEventValues", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679", [
      [ "ObjectInserted", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679a23ec39bcce48de5de8de254aa69a4287", null ],
      [ "ObjectUpdated", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679a7359bd27010684be6931c81aaa4855eb", null ],
      [ "ObjectDeleted", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679a434786cacac73211795629dccc34d417", null ],
      [ "ObjectAltered", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679ac2d3e43dae3f7e7c39da1a7600be04a9", null ],
      [ "ObjectDropped", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679af7865c5e76785c0a0c0a7fc01e41ada5", null ],
      [ "ObjectGeneric", "classocilib_1_1_event.html#a019d692c5e22a1c59dcfc640ae19f679a342c800268d4273d162804a90bc68f96", null ]
    ] ],
    [ "GetType", "classocilib_1_1_event.html#ade44e537f50ac722530f82c0f73db6d2", null ],
    [ "GetObjectEvent", "classocilib_1_1_event.html#a71186b0875124925cc7a5df4abeef653", null ],
    [ "GetDatabaseName", "classocilib_1_1_event.html#ab5916f85034d50780067d34b1bef69a9", null ],
    [ "GetObjectName", "classocilib_1_1_event.html#a6838809560aba4bcc0fb71a0bea4bcf9", null ],
    [ "GetRowID", "classocilib_1_1_event.html#a0d80123251af1a33c093fafc2ee9b9ca", null ],
    [ "GetSubscription", "classocilib_1_1_event.html#a545a749a11dedb46a93f49db2dd1657b", null ]
];