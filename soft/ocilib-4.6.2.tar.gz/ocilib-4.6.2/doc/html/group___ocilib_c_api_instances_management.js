var group___ocilib_c_api_instances_management =
[
    [ "OCI_DatabaseStartup", "group___ocilib_c_api_instances_management.html#ga1f7f4e4a1f7f32d70296281546276ce5", null ],
    [ "OCI_DatabaseShutdown", "group___ocilib_c_api_instances_management.html#ga6c4b72e7ad5c87691fdecca573dca41b", null ]
];