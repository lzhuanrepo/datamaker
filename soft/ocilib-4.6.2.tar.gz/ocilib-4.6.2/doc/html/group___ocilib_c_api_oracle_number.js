var group___ocilib_c_api_oracle_number =
[
    [ "OCI_NumberCreate", "group___ocilib_c_api_oracle_number.html#ga9e87d52f8415f92b0b723165c4f68850", null ],
    [ "OCI_NumberFree", "group___ocilib_c_api_oracle_number.html#gab251ada1166ec3624da9ffc3dbd9aa41", null ],
    [ "OCI_NumberArrayCreate", "group___ocilib_c_api_oracle_number.html#ga7539b88e0253c561488c0ebb24d8bc82", null ],
    [ "OCI_NumberArrayFree", "group___ocilib_c_api_oracle_number.html#ga5477b7ee15f573135d4de8d8ac02d9db", null ],
    [ "OCI_NumberAssign", "group___ocilib_c_api_oracle_number.html#ga7b9c9cab014954fbe7f1a2e4a022cb2d", null ],
    [ "OCI_NumberToText", "group___ocilib_c_api_oracle_number.html#gad96dc5365df97f5167df47990207987a", null ],
    [ "OCI_NumberFromText", "group___ocilib_c_api_oracle_number.html#ga636c9afded7d6f73fb699b8a9d6ee243", null ],
    [ "OCI_NumberGetContent", "group___ocilib_c_api_oracle_number.html#ga2c2f7257e40bbcaeeeee2b4ad99861b0", null ],
    [ "OCI_NumberSetContent", "group___ocilib_c_api_oracle_number.html#ga1fa6ccecc2847238439a6f9209e50ffe", null ],
    [ "OCI_NumberSetValue", "group___ocilib_c_api_oracle_number.html#ga6b10d83add268c55fbc5515a822da503", null ],
    [ "OCI_NumberGetValue", "group___ocilib_c_api_oracle_number.html#gabc9882633298b7049ad4bb54ca33cf7b", null ],
    [ "OCI_NumberAdd", "group___ocilib_c_api_oracle_number.html#gaa4f8cf489461f8df0948b1008306fe9a", null ],
    [ "OCI_NumberSub", "group___ocilib_c_api_oracle_number.html#gaaa0d30de674c467b3065242445e86ec7", null ],
    [ "OCI_NumberMultiply", "group___ocilib_c_api_oracle_number.html#ga8cbd197ebb81995394d2af7cf181f72c", null ],
    [ "OCI_NumberDivide", "group___ocilib_c_api_oracle_number.html#ga9a457b9e399739bbb524b4b7b0ff3967", null ],
    [ "OCI_NumberCompare", "group___ocilib_c_api_oracle_number.html#ga02fc55dbd0ef6be3cab18713f2366840", null ]
];