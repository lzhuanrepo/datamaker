var group___ocilib_c_api_initialization =
[
    [ "OCI_Initialize", "group___ocilib_c_api_initialization.html#ga01464863ddd68393106b63fb8cc1ead1", null ],
    [ "OCI_Cleanup", "group___ocilib_c_api_initialization.html#ga639706aa8e9689c7ebffc018fac6d3ae", null ],
    [ "OCI_GetOCICompileVersion", "group___ocilib_c_api_initialization.html#ga6fa5693d691752f93dbc6baf07e6cceb", null ],
    [ "OCI_GetOCIRuntimeVersion", "group___ocilib_c_api_initialization.html#ga771bf5d33dbd0b63d84242819209b35b", null ],
    [ "OCI_GetImportMode", "group___ocilib_c_api_initialization.html#gaecbebbd3747c5012dfbf072f90e33c77", null ],
    [ "OCI_GetCharset", "group___ocilib_c_api_initialization.html#ga19c86551503e6670c96ef3e81a1ce1ba", null ],
    [ "OCI_GetAllocatedBytes", "group___ocilib_c_api_initialization.html#ga59c50704dae44e650bf53a963d32567b", null ],
    [ "OCI_EnableWarnings", "group___ocilib_c_api_initialization.html#ga60f3ade91299999200076cd53ed9066e", null ],
    [ "OCI_SetErrorHandler", "group___ocilib_c_api_initialization.html#ga1d8013908d583eb37f3e7b15556a3582", null ],
    [ "OCI_SetHAHandler", "group___ocilib_c_api_initialization.html#ga6ba3f601a97363997f47c9bb0cd9e394", null ]
];