var classocilib_1_1_transaction =
[
    [ "TransactionFlags", "classocilib_1_1_transaction.html#a0a91dd5392871791c3687f7a6b49a9f5", null ],
    [ "TransactionFlagsValues", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4", [
      [ "New", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4a569001e3a5a3d415b756c242b298c3ec", null ],
      [ "Tight", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4a165c1301bce197492f9c1898cce6bf23", null ],
      [ "Loose", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4ad0bcf5edb8c2949e24d3664c47c225ec", null ],
      [ "ReadOnly", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4af36f17c42f241c59e4b1a04750e085e0", null ],
      [ "ReadWrite", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4a4545bd6054a1841d65ac77340661965d", null ],
      [ "Serializable", "classocilib_1_1_transaction.html#aad56be300eb5c62bea0e622eb25416b4ac2d7a8f0588816018384575b92632806", null ]
    ] ],
    [ "Transaction", "classocilib_1_1_transaction.html#a5d7965922a67ec4fb9f9759de9539a54", null ],
    [ "Prepare", "classocilib_1_1_transaction.html#ac3b4d4b7e11700048400ec7264fb10a5", null ],
    [ "Start", "classocilib_1_1_transaction.html#a2abaae7bfa114d944b1a29ee66286383", null ],
    [ "Stop", "classocilib_1_1_transaction.html#adcfc66c5dbea6f6c88ee10a947a80a44", null ],
    [ "Resume", "classocilib_1_1_transaction.html#a33334401b173df447f3f2e0e77c1bdbb", null ],
    [ "Forget", "classocilib_1_1_transaction.html#a38c31438fa22d1d83c0aba3084b925fe", null ],
    [ "GetFlags", "classocilib_1_1_transaction.html#a1a89940069c67aae6a5b861557067f22", null ],
    [ "GetTimeout", "classocilib_1_1_transaction.html#ad7087c3f40b68f08074f97d515bca19d", null ]
];