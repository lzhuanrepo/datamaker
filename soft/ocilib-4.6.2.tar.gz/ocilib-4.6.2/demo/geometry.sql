-- Initialization

create table geometry (code int, obj SDO_GEOMETRY);

-- Cleanup

drop table geometry;
