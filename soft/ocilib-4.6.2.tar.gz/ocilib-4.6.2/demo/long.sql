-- Initialization

create table test_long_raw (code int, content long raw);

-- Cleanup

drop table test_long_raw;
